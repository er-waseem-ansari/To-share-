package com.hexaware.EMS.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.EMS.DTO.EmployeeDTO;
import com.hexaware.EMS.entity.AsyncLog;
import com.hexaware.EMS.entity.Employee;
import com.hexaware.EMS.service.EmployeeService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class EmployeeController {
	
	private final EmployeeService employeeService;
	
	@GetMapping("/getAll")
	public ResponseEntity<List<EmployeeDTO>> getAllEmployees(){
		List<EmployeeDTO> employees =  employeeService.getAllEmployees();
		return new ResponseEntity<>(employees,HttpStatus.OK);
	}
	
	@GetMapping("/getById/{id}")
	public ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable Long id) {
		EmployeeDTO employeeDTO =  employeeService.getEmployeeById(id);
		return new ResponseEntity<>(employeeDTO,HttpStatus.OK);
	}
	
	@PostMapping("/addEmployee")
	public ResponseEntity<EmployeeDTO> addEmployee(@RequestBody EmployeeDTO employeeDTO) {
		
		EmployeeDTO employee = employeeService.addEmployee(employeeDTO);
		return new ResponseEntity<>(employee,HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteById/{id}")
	public ResponseEntity<Boolean> deleteById(@PathVariable Long id) {
		Boolean response = employeeService.deleteEmployeeById(id);
		return new ResponseEntity<>(response,HttpStatus.OK);
	}	
	
	@PutMapping("/update/{id}")
	public ResponseEntity<EmployeeDTO> update(@PathVariable Long id, @RequestBody EmployeeDTO employeeDTO) {
		//TODO: process PUT request
		EmployeeDTO employeeDTO1 = employeeService.update(id,employeeDTO);
		return new ResponseEntity<>(employeeDTO1,HttpStatus.OK);
	}
	
	@GetMapping("/getByIdAsync/{id}")
	public ResponseEntity getByIdAsync(@PathVariable Long id) {
		employeeService.getByIdAsync(id);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping("/getByIdResponseAsync/{id}")
	public CompletableFuture<AsyncLog> getByIdResponseAsync(@PathVariable Long id) {
		CompletableFuture<AsyncLog> res = employeeService.getByIdResponseAsync(id);
		return res;
		
	}
	
}












