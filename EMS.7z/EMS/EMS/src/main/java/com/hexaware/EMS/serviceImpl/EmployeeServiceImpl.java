package com.hexaware.EMS.serviceImpl;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.hexaware.EMS.DTO.EmployeeDTO;
import com.hexaware.EMS.entity.AsyncLog;
import com.hexaware.EMS.entity.Employee;
import com.hexaware.EMS.repository.AsyncLogRepo;
import com.hexaware.EMS.repository.EmployeeRepository;
import com.hexaware.EMS.service.EmployeeService;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepository;
	private final AsyncLogRepo asyncLogRepo;

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		List<Employee> employees =  employeeRepository.findAll();
		List<EmployeeDTO> employeeDTOs =  employees.stream().map(it->{
			return EmployeeDTO.builder()
					.email(it.getEmail())
					.department(it.getDepartment())
					.id(it.getId())
					.name(it.getName())
					.phone(it.getPhone())
					.build();
		}).collect(Collectors.toList());
		return employeeDTOs;
	}

	@Override
	public EmployeeDTO getEmployeeById(Long id) {
		Optional<Employee> emp = employeeRepository.findById(id);
		if (emp.isEmpty()) {
			throw new EntityNotFoundException();
		} else {
			Employee employee = emp.get();
			return EmployeeDTO.builder()
					.id(id)
					.department(employee.getDepartment())
					.email(employee.getEmail())
					.name(employee.getName())
					.phone(employee.getPhone())
					.build();	
		}

	}

	@Override
	public EmployeeDTO addEmployee(EmployeeDTO employeeDTO) {
		Employee employee = Employee.builder()
				.department(employeeDTO.getDepartment())
				.email(employeeDTO.getEmail())
				.name(employeeDTO.getName())
				.phone(employeeDTO.getPhone())
				.build();
		Employee saveEmployee =  employeeRepository.save(employee);
		return EmployeeDTO.builder()
				.id(saveEmployee.getId())
				.department(saveEmployee.getDepartment())
				.email(saveEmployee.getEmail())
				.name(saveEmployee.getName())
				.phone(saveEmployee.getPhone())
				.build();
	}

	@Override
	public boolean deleteEmployeeById(Long id) {
		employeeRepository.deleteById(id);
		return true;
	}

	@Override
	@Async
	public void getByIdAsync(Long id) {
		// TODO Auto-generated method stub
		Optional<Employee> emp = employeeRepository.findById(id);
		OffsetDateTime time = OffsetDateTime.now();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		log.warn("inside method");
		
		AsyncLog asyncLog = AsyncLog.builder()
				.issueDate(time)
				.log(emp.get().toString())
				.build();
		
		AsyncLog asyncLog2 = asyncLogRepo.save(asyncLog);
		
		
	}
	
	public CompletableFuture<AsyncLog> getByIdResponseAsync(Long id) {
		Optional<Employee> emp = employeeRepository.findById(id);
		OffsetDateTime time = OffsetDateTime.now();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		log.warn("inside method");
		
		AsyncLog asyncLog = AsyncLog.builder()
				.issueDate(time)
				.log(emp.get().toString())
				.build();
		
		AsyncLog asyncLog2 = asyncLogRepo.save(asyncLog);
		return CompletableFuture.completedFuture(asyncLog2);
	}

	@Override
	public EmployeeDTO update(Long id, EmployeeDTO employeeDTO) {
		
		Employee emp = Employee.builder()
				.name(employeeDTO.getName())
				.department(employeeDTO.getDepartment())
				.email(employeeDTO.getEmail())
				.phone(employeeDTO.getPhone())
				.id(id)
				.build();
		Employee saveEmp = employeeRepository.save(emp);
		
		
		EmployeeDTO empDto = EmployeeDTO.builder()
				.name(saveEmp.getName())
				.department(saveEmp.getDepartment())
				.email(saveEmp.getEmail())
				.phone(saveEmp.getPhone())
				.id(saveEmp.getId())
				.build();
		
		return empDto;
	}
	
	

}
