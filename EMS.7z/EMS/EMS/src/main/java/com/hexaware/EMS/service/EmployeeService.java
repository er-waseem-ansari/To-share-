package com.hexaware.EMS.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.hexaware.EMS.DTO.EmployeeDTO;
import com.hexaware.EMS.entity.AsyncLog;
import com.hexaware.EMS.entity.Employee;

public interface EmployeeService {

	List<EmployeeDTO> getAllEmployees();

	EmployeeDTO getEmployeeById(Long id);

	EmployeeDTO addEmployee(EmployeeDTO employeeDTO);

	boolean deleteEmployeeById(Long id);


	void getByIdAsync(Long id);

	CompletableFuture<AsyncLog> getByIdResponseAsync(Long id);

	EmployeeDTO update(Long id, EmployeeDTO employeeDTO);
	
	
}
