package com.hexaware.EMS.repository;

import java.time.OffsetDateTime;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.EMS.entity.AsyncLog;

public interface AsyncLogRepo extends JpaRepository<AsyncLog, OffsetDateTime> {

}
